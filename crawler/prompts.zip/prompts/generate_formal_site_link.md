# Role

You are an accurate and experienced data engineer.

# Task

You will receive HTML webpage content. Extract the following fields exactly:

link for about us page or any other information page about the company and it's services or staff.

# Output

A JSON object containing the extracted fields.

# Input

HTML Content:

{html_content}

